import 'package:Google_Sheet_with_Flutter/login/begin.dart';
import 'package:Google_Sheet_with_Flutter/login/login.dart';
import 'package:Google_Sheet_with_Flutter/page2/homepage.dart';
import 'package:Google_Sheet_with_Flutter/page2/note/date.dart';
import 'package:Google_Sheet_with_Flutter/page2/note/userdashboard.dart';
import 'package:flutter/material.dart';
import 'package:Google_Sheet_with_Flutter/page/ListTransactionPage.dart';

import 'page/AddTransactionPage.dart';
import 'page/ListTransactionPage.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Google Sheet with Flutter',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: DatePickerDemo(),
    );
  }
}

