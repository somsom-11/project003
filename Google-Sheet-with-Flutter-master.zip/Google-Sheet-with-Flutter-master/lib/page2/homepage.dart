import 'dart:io';

import 'package:Google_Sheet_with_Flutter/page2/homepage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Homepage extends StatefulWidget {
  const Homepage({
    Key key,
    @required this.user,
  }) : super(key: key);
  final FirebaseUser user;

  @override
  _HomePage createState() => _HomePage();
}

class _HomePage extends State<Homepage>

{
  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData(primaryIconTheme: IconThemeData(color: Colors.pink)),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          //leading: Icon(Icons.menu,color: Colors.pink,),
          title:  Text('Home',style: TextStyle(color: Colors.pink,fontSize: 25.0),),
          actions: <Widget>[
            Padding(padding: EdgeInsets.all(10.0),
              child: Container(
                width: 30.0,
                height: 30.0,

              ),)
          ],
        ),
        drawer: Drawer(
          child: ListView(
            // Important: Remove any padding from the ListView.
            padding: EdgeInsets.zero,
            children: <Widget>[
              new DrawerHeader(
                  child: new Container(
                    child: new Column(
                      children: <Widget>[
                        new Text(
                          'App',
                          style: TextStyle(
                              fontSize: 60.0,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Lobster',
                              color: Colors.pink[600]),
                        ),
                        new Text(
                          'Account',
                          style: TextStyle(
                              fontSize: 23.0,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Inter',
                              color: Colors.blue[600]),
                        ),
                        new Text('som',
                          //'${widget.user.email}',
                          style: TextStyle(
                              fontSize: 15.0,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Inter',
                              color: Colors.blue[600]),
                        ),

                      ],
                    ),
                  )),
              ListTile(
                leading: Icon(Icons.stars, color: Colors.purple[400]),
                title: Text('Collect Point',
                    style: TextStyle(
                        fontSize: 20.0,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Inter',
                        color: Colors.purple[400])),
                //onTap: () {Navigator.push(
                //  context, MaterialPageRoute(builder: (context) => mybarcode()));},
              ),
              ListTile(
                leading: Icon(Icons.location_on, color: Colors.lightGreen[600]),
                title: Text('Location',
                    style: TextStyle(
                        fontSize: 20.0,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Inter',
                        color: Colors.lightGreen[600])),
                onTap: () {
                  // Navigator.push(
                  //   context, MaterialPageRoute(builder: (context) => spage()));
                  // Update the state of the app.
                  // ...
                },
              ),
              ListTile(
                leading: Icon(Icons.chat, color: Colors.yellow[700]),
                title: Text('GiveFeedback',
                    style: TextStyle(
                        fontSize: 20.0,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Inter',
                        color: Colors.yellow[700])),
                onTap: () {
                  //  Navigator.push(
                  //    context, MaterialPageRoute(builder: (context) => Sq1()));
                },
              ),
              ListTile(
                leading: Icon(
                  Icons.power_settings_new,
                  color: Colors.deepOrange[700],
                ),
                title: Text('Exit',
                    style: TextStyle(
                        fontSize: 20.0,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Inter',
                        color: Colors.deepOrange[600])),
                onTap: () {
                  exit(0);
                  // Update the state of the app.
                  // ...
                },
              ),
            ],
          ),
        ),
        body: page1(),
      ),


    );

  }}


class page1 extends StatefulWidget{

  @override
  _page1 createState() => _page1();

}
class _page1 extends State<page1>{
  @override

  Widget build(BuildContext context){
    return
      ListView(
        children: [
          SizedBox(height: 15.0),
          Text('  Categories',
              style: TextStyle(
                  fontFamily: 'Varela',
                  fontSize: 42.0,
                  color: Colors.pink,
                  fontWeight: FontWeight.bold)),
          SizedBox(height: 5.0),
          SafeArea(child: SingleChildScrollView(
            padding: EdgeInsets.all(2.0),
            child: Column(
              children: <Widget>[
              Container(padding: EdgeInsets.only(left: 8.0,right: 8.0,top: 10.0,bottom: 1.0),
                height: MediaQuery.of(context).size.height *0.2,
                child: Card(
                  color: Colors.deepPurpleAccent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.0),
              ),
              elevation: 8,
                  child: Container(
                    child: Center(),
              ),
            ),

              ),
                Row(mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(child: Container(padding: EdgeInsets.only(left: 10.0,right: 0.0,top: 5.0,bottom: 1.0),
                      height: MediaQuery.of(context).size.height * 0.25,
                      child: Card(
                        color: Colors.deepPurpleAccent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        elevation: 8,
                        child: Container(
                          child: Center(),
                        ),
                      ),

                    ),),
                    Expanded(child: Container(padding: EdgeInsets.only(left: 0.0,right: 10.0,top: 5.0,bottom: 1.0),
                      height: MediaQuery.of(context).size.height * 0.25,
                      child: Card(
                        color: Colors.deepPurpleAccent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        elevation: 8,
                        child: Container(
                          child: Center(),
                        ),
                      ),

                    ),)
                  ],
                ),
                Row(mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(child: Container(padding: EdgeInsets.only(left: 10.0,right: 0.0,top: 5.0,bottom: 1.0),
                      height: MediaQuery.of(context).size.height * 0.25,
                      child: Card(
                        color: Colors.deepPurpleAccent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        elevation: 8,
                        child: Container(
                          child: Center(),
                        ),
                      ),

                    ),),
                    Expanded(child: Container(padding: EdgeInsets.only(left: 0.0,right: 10.0,top: 5.0,bottom: 1.0),
                      height: MediaQuery.of(context).size.height * 0.25,
                      child: Card(
                        color: Colors.deepPurpleAccent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        elevation: 8,
                        child: Container(
                          child: Center(),
                        ),
                      ),

                    ),)
                  ],
                )

              ],
            ),
          ))
        ],
      );

  }

}
